package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Noticia;
import services.NoticiaService;

/**
 * Servlet implementation class ListarNoticia
 */
@WebServlet("/ListarNoticia.do")
public class ListarNoticia extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			NoticiaService nS = new NoticiaService();
			
			ArrayList<Noticia> listaNoticias = nS.ListarNoticias();
			
			response.setContentType("text/html");
		
		PrintWriter saida = response.getWriter();
		
		saida.println("Lista de Noticias: ");
		
		for(Noticia n: listaNoticias) {
			saida.println("Nome: "+n.getTitulo()
						+"<br>"+n.getId()
						+"<br>"+n.getTexto()
						+"<br>"+n.getDescricao());
		saida.println("<h1>Adicionar coment�rio a essa not�cia" + "<br>");
		saida.println("Nome: <input type=\"text\" name= \"Nome:\" style=\"height:30px;\"><br>");
		saida.println("Comentario: <input type=\"text\" name= \"Comentario:\" style=\"height:150px;\"><br>");
		}
	}

}