package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Comentario;
import services.ComentarioService;

/**
 * Servlet implementation class ExcluirComentario
 */
@WebServlet("/ExcluirComentario.do")
public class ExcluirComentario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id_comentario"));
		
		ComentarioService cS = new ComentarioService();
		
		Comentario c = new Comentario();
		
		c.setId(id);
		cS.excluir(c);
		
		PrintWriter saida = response.getWriter();
		saida.println("O coment�rio foi removido com sucesso!!");
		
		
	}

}