package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Comentario;
import services.ComentarioService;

/**
 * Servlet implementation class ListarComentario
 */
@WebServlet("/ListarComentario.do")
public class ListarComentario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	   
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			ComentarioService cS = new ComentarioService();
			
			ArrayList<Comentario> listaComentarios = cS.ListarComentarios();
			
			response.setContentType("text/html");
			
			PrintWriter saida = response.getWriter();
			
			saida.println("Lista de comentarios: ");
			
			for(Comentario c: listaComentarios) {
				saida.println("Nome: "+c.getNome()
							+"<br>"+c.getId()
							+"<br>"+c.getTexto());
			}
		}

	}
