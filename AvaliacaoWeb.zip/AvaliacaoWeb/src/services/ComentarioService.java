package services;

import java.util.ArrayList;

import dao.ComentarioDAO;
import model.Comentario;

public class ComentarioService {

	private ComentarioDAO comentarioDAO;
	
	public ComentarioService() {
		this.comentarioDAO = new ComentarioDAO();
	}
	
	public void cadastrar(Comentario comentario) {
		comentarioDAO.cadastrar(comentario);
	}
	
	public void alterar(Comentario comentario) {
		comentarioDAO.alterar(comentario);
	}
	
	public void excluir(Comentario comentario) {
		comentarioDAO.excluir(comentario);
	}
	
	public ArrayList<Comentario> ListarComentarios() {
		return comentarioDAO.listarComentarios();
	}
}
